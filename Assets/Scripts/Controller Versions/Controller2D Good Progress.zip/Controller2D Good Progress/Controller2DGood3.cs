using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Controller2DGood3 : RaycastController {

    public float maxSlopeAngle = 55;

    public CollisionInfo collisions;
    Vector2 originalMoveAmount;

    public override void Start() {
        base.Start();
    }

    public void Move(Vector2 moveAmount, bool standingOnPlatform = false) {
        originalMoveAmount = moveAmount;
        UpdateRaycastOrigins ();
        collisions.Reset ();
        collisions.moveAmountOld = moveAmount;
        
        if (moveAmount.x != 0) {
            HorizontalCollisions (ref moveAmount);
            HandleClimbSlope(ref moveAmount);
        }
        // moves player
        // snaps to ground
        if (moveAmount.y < 0){
            BelowCollisions (ref moveAmount);
            BelowEdgeCollisions (ref moveAmount);
        } 

        transform.Translate (moveAmount);

        if (standingOnPlatform) {
            collisions.below = true;
        }
    }


    void HorizontalCollisions (ref Vector2 moveAmount) {
        float directionX = Mathf.Sign(moveAmount.x);
        float rayLength = Mathf.Abs(moveAmount.x) + skinWidth;


        // look for wall collisions
        for (int i = 0; i < horizontalRayCount; i++) {
            Vector2 rayOrigin = (directionX == -1)?raycastOrigins.bottomLeft:raycastOrigins.bottomRight;
            rayOrigin += Vector2.up * (horizontalRaySpacing * i);
            RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.right * directionX, rayLength, collisionMask);
            
            Debug.DrawRay(rayOrigin, Vector2.right * directionX * rayLength, Color.red);

            if (hit) {
                if (hit.collider.tag == "Cloud") {
                    continue;
                }
                if (hit.distance == 0) {
                    continue;
                }
                float slopeAngle = Vector2.Angle (hit.normal, Vector2.up);

                if (slopeAngle > maxSlopeAngle) {
                    moveAmount.x = (hit.distance - skinWidth) * directionX;
                    rayLength = hit.distance;

                    collisions.left = directionX == -1;
                    collisions.right = directionX == 1;
                }
            }
        }
    }
    
    void HandleClimbSlope (ref Vector2 moveAmount) {
        float directionX = Mathf.Sign(moveAmount.x);
        float rayLength = Mathf.Abs(moveAmount.x);

        // FIRST:
        // racast from bottom (inset by skin) in x move dir. if slope is hit, move to slope, handle climbing
        RaycastHit2D hit = Physics2D.Raycast(raycastOrigins.bottom, Vector2.right * directionX, rayLength, collisionMask);

        if (hit) {
            if (hit.distance == 0 || hit.collider.tag == "Cloud") return;

            float slopeAngle = Vector2.Angle (hit.normal, Vector2.up);
            // climbing slope
            if (slopeAngle > 0 && slopeAngle <= maxSlopeAngle) {
                float distToSlopeStart = 0;
                if (slopeAngle != collisions.slopeAngleOld) {
                    distToSlopeStart = hit.distance - skinWidth;
                    moveAmount.x -= distToSlopeStart * directionX;
                }
                ClimbSlope(ref moveAmount, slopeAngle, hit.normal);
                moveAmount.x += distToSlopeStart * directionX;
                moveAmount.y += skinWidth;
            }
        }
    }

    void ClimbSlope(ref Vector2 moveAmount, float slopeAngle, Vector2 slopeNormal) {
        float moveDistance = Mathf.Abs(moveAmount.x);
        float climbmoveAmountY = Mathf.Sin(slopeAngle * Mathf.Deg2Rad) * moveDistance;

        Vector2 preClimbMove = moveAmount;

        // if we are not jumping on a slope, climb the slope
        //if (moveAmount.y <= 0) {
        moveAmount.y = climbmoveAmountY;
        moveAmount.x = Mathf.Cos(slopeAngle * Mathf.Deg2Rad) * moveDistance * Mathf.Sign(moveAmount.x);
            

        // dont cancel out vertical movement
        if (preClimbMove.y > moveAmount.y) {
            moveAmount.y = preClimbMove.y;
        }
        else {
            collisions.below = true;
            collisions.onSlope = true;
            collisions.climbingSlope = true;
            collisions.slopeAngle = slopeAngle;
            collisions.slopeNormal = slopeNormal;
        }
        //}
    }

    void BelowCollisions (ref Vector2 moveAmount) {

        float rayLength = Mathf.Abs(moveAmount.y) + skinWidth;

        // if we were grounded, and we still have downard force...
        // increase ray based on how much x movement there is to insure that it can detect the steepest climbalbe sope downward
        if (collisions.wasGrounded && Mathf.Abs(moveAmount.x) > 0) {
            float longerRay = (Mathf.Abs(moveAmount.x) / Mathf.Tan((90-maxSlopeAngle) * Mathf.Deg2Rad)) + skinWidth;
            if (longerRay > rayLength) {
                rayLength = longerRay;
            }
        }

        // cast ray down from where we will be after having moved
        Vector2 rayOrigin = raycastOrigins.bottom + Vector2.right * moveAmount.x;// + Vector2.up * moveAmount.y;

        // shoot ray down from bottom center
        RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.down, rayLength, collisionMask);

        if (hit) {
            // continue if inside a collider, or collider is a cloud
            float slopeAngle = Vector2.Angle (hit.normal, Vector2.up);

            if (slopeAngle <= maxSlopeAngle) {
                moveAmount.y = (hit.distance - skinWidth) * -1;
                collisions.below = true;
                // remain on sope
                if (slopeAngle != 0) {
                    collisions.onSlope = true;
                    collisions.slopeAngle = slopeAngle;
                }
            }
        }
    }

    void BelowEdgeCollisions (ref Vector2 moveAmount) {
        // FOR DEBUG, TURN THIS ON
        //GTime.timeScale = 0.1f;

        // we only need to check this if we are NOT on a slope.
        if (collisions.onSlope) return;

        // handle flat cliffs and downward sloping cliffs
        RaycastHit2D hitLeft =  Physics2D.Raycast(raycastOrigins.bottomLeft  + Vector2.left * skinWidth,  Vector2.down, Mathf.Abs(moveAmount.y) + skinWidth, collisionMask);
        RaycastHit2D hitRight = Physics2D.Raycast(raycastOrigins.bottomRight + Vector2.right * skinWidth, Vector2.down, Mathf.Abs(moveAmount.y) + skinWidth, collisionMask);

        if (hitLeft || hitRight) {
            BelowEdge(hitLeft, ref moveAmount);
            BelowEdge(hitRight, ref moveAmount);
        }

        // handle walking off upward sloping cliff
        if (collisions.wasGrounded && !collisions.below) {
            Vector2 rayOrigin = raycastOrigins.bottom + Vector2.down * skinWidth + Vector2.right * moveAmount;
            float rayLength = (raycastOrigins.bounds.size.x * 0.5f) + skinWidth;

            float slopeAngle = 0;
            RaycastHit2D cliffEdgeCheck = Physics2D.Raycast(rayOrigin, Vector2.right * -1, rayLength, collisionMask);
            WalkOffClipEdgeHit(cliffEdgeCheck, ref moveAmount);
            
            if (!collisions.below) cliffEdgeCheck = Physics2D.Raycast(rayOrigin, Vector2.right * 1, rayLength, collisionMask);
            WalkOffClipEdgeHit(cliffEdgeCheck, ref moveAmount);
        }

        // falling version
        if (!collisions.wasGrounded && !collisions.below) {
            Vector2 rayOrigin = raycastOrigins.bottom + Vector2.down * skinWidth + Vector2.right * moveAmount;
            float rayLength = (raycastOrigins.bounds.size.x * 0.5f) + skinWidth;

            // bump away from walls
            RaycastHit2D bumpOffWallCheck = Physics2D.Raycast(rayOrigin, Vector2.right * -1, rayLength, collisionMask);
            BumpAwayFromWall (bumpOffWallCheck, ref moveAmount);
            bumpOffWallCheck = Physics2D.Raycast(rayOrigin, Vector2.right * 1, rayLength, collisionMask);
            BumpAwayFromWall (bumpOffWallCheck, ref moveAmount);

            // recalulate ray progom
            rayOrigin = raycastOrigins.bottom + Vector2.down * skinWidth + Vector2.right * moveAmount;

            float slopeAngle = 0;
            RaycastHit2D cliffEdgeCheck = Physics2D.Raycast(rayOrigin, Vector2.right * -1, rayLength, collisionMask);
            FallOffCliffEdgeHit(cliffEdgeCheck, ref moveAmount);
            if (!collisions.below) cliffEdgeCheck = Physics2D.Raycast(rayOrigin, Vector2.right * 1, rayLength, collisionMask);
            FallOffCliffEdgeHit(cliffEdgeCheck, ref moveAmount);
            
        }
    }

    void WalkOffClipEdgeHit(RaycastHit2D hit, ref Vector2 moveAmount) {
        if (!hit) return;
        float slopeAngle = Vector2.Angle (hit.normal, Vector2.up);

        if (slopeAngle >= maxSlopeAngle) { 
            //DrawPoint(cliffEdgeCheck.point, Color.blue, 0.01f);
            if (moveAmount.y < 0) moveAmount.y = 0;
            collisions.below = true;
        }
    }

    void BumpAwayFromWall (RaycastHit2D hit, ref Vector2 moveAmount) {
        if (!hit) return;
        float slopeAngle = Vector2.Angle (hit.normal, Vector2.up);
        if (slopeAngle >= maxSlopeAngle) {
            if (hit.distance > raycastOrigins.bounds.size.x * 0.5f) moveAmount.x += Mathf.Sign(hit.normal.x) * skinWidth * 0.01f;
        }
    }

    void FallOffCliffEdgeHit(RaycastHit2D hit, ref Vector2 moveAmount) {
        if (!hit) return;
        float slopeAngle = Vector2.Angle (hit.normal, Vector2.up);

        if (slopeAngle >= maxSlopeAngle) {
            // next we cast a ray downward from the player at that x value to get the actual fall distance
            //DrawPoint(cliffEdgeCheck.point, Color.black, 0.01f);
            Vector2 rayOrigin = new Vector2(hit.point.x, raycastOrigins.bottom.y - skinWidth);
            DrawPoint(rayOrigin, Color.cyan, 0.05f);

            Debug.DrawRay(rayOrigin, Vector2.down * Mathf.Abs(moveAmount.y), Color.yellow);
            RaycastHit2D edgeHit = Physics2D.Raycast(rayOrigin, Vector2.down, Mathf.Abs(moveAmount.y), collisionMask);
            if (edgeHit) {
                moveAmount.y = -edgeHit.distance;
                collisions.below = true;
                DrawPoint(edgeHit.point, Color.yellow, 0.05f);
            }
        }
    }

    void BelowEdge (RaycastHit2D hit, ref Vector2 moveAmount) {
        // SO FAR THIS ONLY HANDLES DOWNWARD SLOPING EDGES
        if (hit) {
            if (hit.distance == 0 && !collisions.wasGrounded) return;
            float slopeAngle = Vector2.Angle (hit.normal, Vector2.up);
            if (slopeAngle > 0 && slopeAngle < maxSlopeAngle) {
                // adjasent side = dist from hit corner to center of collider
                float adj = (raycastOrigins.bounds.size.x * 0.5f) + skinWidth;
                float opp = Mathf.Tan(maxSlopeAngle * Mathf.Deg2Rad) * adj;

                // added additional skin width to be super safe
                RaycastHit2D slopeCheck = Physics2D.Raycast(raycastOrigins.bottom, Vector2.down, opp + skinWidth * 2, collisionMask);
                Debug.DrawRay(raycastOrigins.bottom, Vector2.down * (opp + skinWidth * 2), Color.cyan, 1);
                bool sideWallsDetected = false;

                if (slopeCheck) {
                    bool _edgeDebugs = false;
                    // sanity check. Fire rays from 1/4, 1/2 and 3/4 between [hit point] and [slopeCheck hit point]
                    // fire them in the Mathf.Sign(hit.normal.x) direction. Ray Length = raycastBounds.size * 0.5 + skinWidth.
                    // if any rays hit a surface with a slope >= maxSlope then cancel the "slope".
                    // this stops you from falling through a corner
                    for (int i = 0; i < 3; i++) {
                        Vector2 _checkPt = new Vector2 (raycastOrigins.bottom.x, Mathf.Lerp(slopeCheck.point.y, hit.point.y, 0.25f * (float)(i + 1)));
                        float _rayLength = (raycastOrigins.bounds.size.x * 0.5f) + skinWidth;
                        if (_edgeDebugs) DrawPoint(_checkPt, Color.green, 0.02f);

                        RaycastHit2D wallChecker = Physics2D.Raycast(_checkPt, Vector2.right * -Mathf.Sign(hit.normal.x), _rayLength, collisionMask);
                        if (wallChecker) {
                            if (_edgeDebugs) DrawPoint(wallChecker.point, Color.black, 0.05f);
                            float wallAngle = Vector2.Angle (wallChecker.normal, Vector2.up);
                            if (wallAngle >= maxSlopeAngle) {
                                sideWallsDetected = true;
                                break;
                            }
                        }
                    }
                }
                if (slopeCheck && !sideWallsDetected) {
                    DrawPoint(slopeCheck.point, Color.white, 0.1f);

                    slopeAngle = Vector2.Angle (slopeCheck.normal, Vector2.up);
                    collisions.onSlope = true;
                    return;
                }
                else {
                    slopeAngle = 0;
                    collisions.onSlope = false;
                }
            }
            if (slopeAngle == 0 && !collisions.onSlope) {
                moveAmount.y = (hit.distance>skinWidth) ? (hit.distance - skinWidth) * -1 : 0;
                collisions.below = true;
            }
        }
    }


    // hitting head
        // updates x moveAmount when on a slope and a collision above you occurs
        // if (collisions.climbingSlope) {
        //     moveAmount.x = moveAmount.y / Mathf.Tan(collisions.slopeAngle * Mathf.Deg2Rad) * Mathf.Sign(moveAmount.x);
        // }



    void DrawPoint(Vector2 point, Color color, float size = 0.3f) {
        Debug.DrawLine(point + Vector2.left * size * 0.5f, point + Vector2.right * size * 0.5f, color, 1);
        Debug.DrawLine(point + Vector2.up * size * 0.5f, point + Vector2.down * size * 0.5f, color, 1);
    }

    public struct CollisionInfo {
        public bool above, below;
        public bool left, right;

        public bool wasGrounded;

        public bool onSlope;
        public bool climbingSlope; // do i need?
        public bool descendingSlope; // do i need?
        public bool slidingDownMaxSlope;

        public float slopeAngle, slopeAngleOld;
        public Vector2 slopeNormal;
        public Vector2 moveAmountOld;
        public int faceDir;
        public bool fallingThroughPlatform;

        public void Reset() {
            wasGrounded = below;

            above = below = false;
            left = right = false;
            climbingSlope = false;
            descendingSlope = false;
            slidingDownMaxSlope = false;
            slopeNormal = Vector2.zero;
            onSlope = false;

            slopeAngleOld = slopeAngle;
            slopeAngle = 0;
        }
    }

    /*

    public void Move(Vector2 moveAmount, bool standingOnPlatform = false) {
        Move (moveAmount, Vector2.zero, standingOnPlatform);
    } 

    public void Move(Vector2 moveAmount, Vector2 input, bool standingOnPlatform = false) {
        UpdateRaycastOrigins ();
        collisions.Reset ();
        collisions.moveAmountOld = moveAmount;
        playerInput = input;

        if (moveAmount.y < 0) {
            DescendSlope(ref moveAmount);
        }
        if (moveAmount.x != 0) {
            collisions.faceDir = (int)Mathf.Sign(moveAmount.x);
            // remove the (moveAmount.x != 0) if statement this to always check for horizontal collisions to do wall sliding at all times
            HorizontalCollisions (ref moveAmount);
        }
        if (moveAmount.y != 0) {
            VerticalCollisions (ref moveAmount);
        }


        transform.Translate (moveAmount);

        if (standingOnPlatform) {
            collisions.below = true;
        }
    }

    void HorizontalCollisions(ref Vector2 moveAmount) {
        float directionX = collisions.faceDir; //Mathf.Sign (moveAmount.x);
        float rayLength = Mathf.Abs(moveAmount.x) + skinWidth;

        // only nessesary if we remove the (moveAmount.x != 0) requirement for HorizontalCollisions
        if (Mathf.Abs(moveAmount.x) < skinWidth) {
            rayLength = 2 * skinWidth;
        }
        
        if (useColliderToRaycast) {
            // first cast single ray from bottom to handle slope
            Vector2 rayOrigin = (directionX == -1)?raycastOrigins.bottomLeft:raycastOrigins.bottomRight;
            RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.right * directionX, rayLength, collisionMask);
            Debug.DrawRay(rayOrigin, Vector2.right * directionX * rayLength * 2, Color.red);

            if (hit) {
                //Debug.Break();
                DrawPoint(hit.point, Color.yellow, 0.05f);
                if (hit.collider.tag != "Cloud" && hit.distance != 0) {
                    HandleHorizontalHit(hit, ref moveAmount, ref rayLength, directionX, 0); // ending in 0 tells it to caclulate slopes
                }
            }

            // next cast a boxcast to handle wall collisions
            hit = Physics2D.BoxCast (raycastOrigins.bounds.center, raycastOrigins.bounds.size, 0, Vector2.right * directionX, rayLength, collisionMask);
            if (hit) {
                DrawPoint(hit.point, Color.cyan, 0.05f);
                if (hit.collider.tag != "Cloud") {
                    HandleHorizontalHit(hit, ref moveAmount, ref rayLength, directionX, 1); // ending this in 1 tells it to ingore all slopes
                }
            }
        }
        else {
            // ray origin version
            for (int i = 0; i < horizontalRayCount; i++) {
                Vector2 rayOrigin = (directionX == -1)?raycastOrigins.bottomLeft:raycastOrigins.bottomRight;
                rayOrigin += Vector2.up * (horizontalRaySpacing * i);
                RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.right * directionX, rayLength, collisionMask);
                
                Debug.DrawRay(rayOrigin, Vector2.right * directionX * rayLength * 2, Color.red);

                if (hit) {
                    if (hit.collider.tag == "Cloud") {
                        continue;
                    }
                    if (hit.distance == 0) {
                        continue;
                    }
                    HandleHorizontalHit(hit, ref moveAmount, ref rayLength, directionX, i);
                }
            }
        }
    }

    void HandleHorizontalHit (RaycastHit2D hit, ref Vector2 moveAmount, ref float rayLength, float directionX, int i = 0) {
        float slopeAngle = Vector2.Angle (hit.normal, Vector2.up);

        // climbing slope
        if (i == 0 && slopeAngle <= maxSlopeAngle) {
            // fix for charachter slowing down in a V saped platform, where two steep slopes meet.
            if (collisions.descendingSlope) {
                collisions.descendingSlope = false;
                moveAmount = collisions.moveAmountOld;
            }
            float distToSlopeStart = 0;
            // move to slope, then climb
            if (slopeAngle != collisions.slopeAngleOld) {
                distToSlopeStart = hit.distance-skinWidth;
                moveAmount.x -= distToSlopeStart * directionX;
            }
            ClimbSlope(ref moveAmount, slopeAngle, hit.normal);
            // add back the distantance to slope so you close the distance to the slope
            moveAmount.x += distToSlopeStart * directionX;
            rayLength = Mathf.Abs(moveAmount.x) + skinWidth; // added
        }

        if ((!collisions.climbingSlope || slopeAngle > maxSlopeAngle)) {
            moveAmount.x = (hit.distance - skinWidth) * directionX;
            rayLength = hit.distance;

            // update y moveAmount if climbing a slope so we dont jitter when we collide with something from the side
            if (collisions.climbingSlope) {
                moveAmount.y = Mathf.Tan(collisions.slopeAngle * Mathf.Deg2Rad) * Mathf.Abs(moveAmount.x);
            }

            collisions.left = directionX == -1;
            collisions.right = directionX == 1;
        }
    }

    void VerticalCollisions(ref Vector2 moveAmount) {
        float directionY = Mathf.Sign (moveAmount.y);
        float rayLength = Mathf.Abs(moveAmount.y) + skinWidth;

        // check for toe touching slope if moving down and has x velocity
        if (directionY == -1 && moveAmount.x != 0) ToeOnSlopeCheck(ref moveAmount);

        if (useColliderToRaycast) {
            Bounds verticalCollisonBounds = raycastOrigins.bounds;
            float heightOffset = verticalCollisonBounds.size.y * 0.25f;
            verticalCollisonBounds.size = new Vector2 (verticalCollisonBounds.size.x, verticalCollisonBounds.size.y * 0.5f);

            Vector2 rayOrigin = (Vector2)raycastOrigins.bounds.center + Vector2.up * directionY * heightOffset;
            rayOrigin += Vector2.right * moveAmount.x;

            // version using collider.Raycast
            RaycastHit2D hit = Physics2D.BoxCast (rayOrigin, verticalCollisonBounds.size, 0, Vector2.up * directionY, rayLength, collisionMask);
            if (hit) {
                bool skip = false;
                if (hit.collider.tag == "Cloud") {
                    if (directionY == 1 || hit.distance == 0) {
                        skip = true;
                    }
                    if (collisions.fallingThroughPlatform) {
                        skip = true;
                    }
                    if (playerInput.y == -1) {
                        collisions.fallingThroughPlatform = true;
                        Invoke("ResetFallingThroughPlatform", 0.25f);
                        skip = true;
                    }
                }
                if (!skip) {
                    HandleVerticalHit(hit, ref moveAmount, ref rayLength, directionY);
                }
                
            }
        }
        else {
            for (int i = 0; i < verticalRayCount; i++) {
                Vector2 rayOrigin = (directionY == -1)?raycastOrigins.bottomLeft:raycastOrigins.topLeft;
                rayOrigin += Vector2.right * (verticalRaySpacing * i + moveAmount.x);
                RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.up * directionY, rayLength, collisionMask);
                
                Debug.DrawRay(rayOrigin, Vector2.up * directionY * rayLength * 2, Color.red);

                if (hit) {
                    if (hit.collider.tag == "Cloud") {
                        if (directionY == 1 || hit.distance == 0) {
                            continue;
                        }
                        if (collisions.fallingThroughPlatform) {
                            continue;
                        }
                        if (playerInput.y == -1) {
                            collisions.fallingThroughPlatform = true;
                            Invoke("ResetFallingThroughPlatform", 0.25f);
                            continue;
                        }
                    }
                    HandleVerticalHit(hit, ref moveAmount, ref rayLength, directionY);
                }
            }
        }
        
        // fix for charachter getting stuck for a frame when two slopes meet
        if (collisions.climbingSlope) {
            float directionX = Mathf.Sign(moveAmount.x);
            rayLength = Mathf.Abs(moveAmount.x) + skinWidth;
            Vector2 rayOrigin = ((directionX == -1)?raycastOrigins.bottomLeft:raycastOrigins.bottomRight) + Vector2.up * moveAmount.y;
            RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.right * directionX, rayLength, collisionMask);
            
            if (hit) {
                float slopeAngle = Vector2.Angle(hit.normal, Vector2.up);
                if (slopeAngle != collisions.slopeAngle) {
                    moveAmount.x = (hit.distance - skinWidth) * directionX;
                    collisions.slopeAngle = slopeAngle;
                    collisions.slopeNormal = hit.normal;
                }
            }
        }
    }

    void HandleVerticalHit (RaycastHit2D hit, ref Vector2 moveAmount, ref float rayLength, float directionY) {
        moveAmount.y = (hit.distance - skinWidth) * directionY;
        rayLength = hit.distance;

        //DrawPoint(hit.point, Color.white);

        // updates x moveAmount when on a slope and a collision above you occurs
        if (collisions.climbingSlope) {
            moveAmount.x = moveAmount.y / Mathf.Tan(collisions.slopeAngle * Mathf.Deg2Rad) * Mathf.Sign(moveAmount.x);
        }

        collisions.below = directionY == -1;
        collisions.above = directionY == 1;
    }

    // if you edge up onto a slope without the horizontal collision detecting it, undo the x movement so you stay at the foot of the slope
    void ToeOnSlopeCheck(ref Vector2 moveAmount) {
            // fire a ray down from new ray origin (including x movement.)
            // if it hits inside skin width:
                // we use skinWidth - hit.distance to get the leg of the triangle + the angle of the normal to get the other leg (not the hypotonute).
                // We then subtract that distance from the moveAmount.x
            Vector2 rayOrigin = (moveAmount.x < 0)?raycastOrigins.bottomLeft:raycastOrigins.bottomRight;
            rayOrigin.x += moveAmount.x;
            RaycastHit2D hit = Physics2D.Raycast(rayOrigin, -Vector2.up, skinWidth * 1.1f, collisionMask);
            if (hit && hit.distance < skinWidth && hit.normal.y != 1) {
                float slopeAngle = Vector2.Angle(hit.normal, Vector2.up);
                float legLength = skinWidth - hit.distance;
                float xShift = legLength / Mathf.Tan(slopeAngle * Mathf.Deg2Rad);
                moveAmount += Vector2.right * xShift * Mathf.Sign(hit.normal.x);
            }
    }

    void ClimbSlope(ref Vector2 moveAmount, float slopeAngle, Vector2 slopeNormal) {
        float moveDistance = Mathf.Abs(moveAmount.x);
        float climbmoveAmountY = Mathf.Sin(slopeAngle * Mathf.Deg2Rad) * moveDistance;

        // if we are not jumping on a slope, climb the slope
        if (moveAmount.y <= climbmoveAmountY) {
            moveAmount.y = climbmoveAmountY;
            moveAmount.x = Mathf.Cos(slopeAngle * Mathf.Deg2Rad) * moveDistance * Mathf.Sign(moveAmount.x);
            collisions.below = true;
            collisions.climbingSlope = true;
            collisions.slopeAngle = slopeAngle;
            collisions.slopeNormal = slopeNormal;
        }
    }

    void DescendSlope(ref Vector2 moveAmount) {

        // SLIDING
        RaycastHit2D maxSlopeHitLeft =  Physics2D.Raycast(raycastOrigins.bottomLeft, -Vector2.up, Mathf.Abs(moveAmount.y) + skinWidth, collisionMask);
        RaycastHit2D maxSlopeHitRight = Physics2D.Raycast(raycastOrigins.bottomRight, -Vector2.up, Mathf.Abs(moveAmount.y) + skinWidth, collisionMask);
        
        //Debug.DrawRay(raycastOrigins.bottomLeft, -Vector2.up * (Mathf.Abs(moveAmount.y) + skinWidth), Color.black);
        if (maxSlopeHitLeft || maxSlopeHitRight) { //(maxSlopeHitLeft ^ maxSlopeHitRight)
            // fixes getting "captured" by a very gentle slope and being pulled down even when standing on flat ground
            if (maxSlopeHitLeft && maxSlopeHitRight) {
                // if the left hit is the closer one, only do left
                if (maxSlopeHitLeft.distance < maxSlopeHitRight.distance) SlideDownMaxSlope(maxSlopeHitLeft, ref moveAmount);
                // if the right hit is the closer one, only do right
                if (maxSlopeHitRight.distance < maxSlopeHitLeft.distance) SlideDownMaxSlope(maxSlopeHitRight, ref moveAmount);
            } 
            else {
                SlideDownMaxSlope(maxSlopeHitLeft, ref moveAmount);
                SlideDownMaxSlope(maxSlopeHitRight, ref moveAmount);
            }
        }

        if (!collisions.slidingDownMaxSlope) {
            float directionX = Mathf.Sign (moveAmount.x);

            // if (useColliderToRaycast) {
            //     Bounds skinnedBounds = colliderBox.bounds;
            //     skinnedBounds.Expand(skinWidth * -2);
            //     RaycastHit2D hit = Physics2D.BoxCast (raycastOrigins.center, skinnedBounds.size, 0, -Vector2.up, Mathf.Infinity, collisionMask);
            //     if (hit) DescendSlopeHit(hit, ref moveAmount, directionX);
            // }
            // else {
                Vector2 rayOrigin = (directionX == -1) ? raycastOrigins.bottomRight : raycastOrigins.bottomLeft;
                RaycastHit2D hit = Physics2D.Raycast(rayOrigin, -Vector2.up, Mathf.Infinity, collisionMask);

                if (hit) {
                    DescendSlopeHit(hit, ref moveAmount, directionX);
                }
            //}
        }
    }

    void DescendSlopeHit (RaycastHit2D hit, ref Vector2 moveAmount, float directionX) {
        float slopeAngle = Vector2.Angle(hit.normal, Vector2.up);
        if (slopeAngle != 0 && slopeAngle <= maxSlopeAngle) {
            if (Mathf.Sign(hit.normal.x) == directionX) {
                // if distance to slope is less than how far we have to move on the y access then we are close enough to use slope
                if (hit.distance - skinWidth <= Mathf.Tan(slopeAngle * Mathf.Deg2Rad) * Mathf.Abs(moveAmount.x)) {
                    float moveDistance = Mathf.Abs(moveAmount.x);
                    float descendmoveAmountY = Mathf.Sin(slopeAngle * Mathf.Deg2Rad) * moveDistance;
                    moveAmount.x = Mathf.Cos(slopeAngle * Mathf.Deg2Rad) * moveDistance * Mathf.Sign(moveAmount.x);
                    moveAmount.y -= descendmoveAmountY;

                    collisions.slopeAngle = slopeAngle;
                    collisions.descendingSlope = true;
                    collisions.below = true;
                    collisions.slopeNormal = hit.normal;
                }
            }
        }
    }


    void SlideDownMaxSlope (RaycastHit2D hit, ref Vector2 moveAmount) {
        if (hit) {
            float slopeAngle = Vector2.Angle(hit.normal, Vector2.up);
            if (slopeAngle > maxSlopeAngle) {
                moveAmount.x = hit.normal.x * Mathf.Abs((Mathf.Abs(moveAmount.y) - hit.distance) / Mathf.Tan(slopeAngle * Mathf.Deg2Rad));
                collisions.slopeAngle = slopeAngle;
                collisions.slidingDownMaxSlope = true;
                collisions.slopeNormal = hit.normal;
            }
        }
    }



    void ResetFallingThroughPlatform() {
        collisions.fallingThroughPlatform = false;
    }

    public struct CollisionInfo {
        public bool above, below;
        public bool left, right;

        public bool climbingSlope;
        public bool descendingSlope;
        public bool slidingDownMaxSlope;

        public float slopeAngle, slopeAngleOld;
        public Vector2 slopeNormal;
        public Vector2 moveAmountOld;
        public int faceDir;
        public bool fallingThroughPlatform;

        public void Reset() {
            above = below = false;
            left = right = false;
            climbingSlope = false;
            descendingSlope = false;
            slidingDownMaxSlope = false;
            slopeNormal = Vector2.zero;

            slopeAngleOld = slopeAngle;
            slopeAngle = 0;
        }
    }
    */
}
