using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Controller2DOnlyOneBoxCheck : RaycastController {

    public float maxSlopeAngle = 80;
    public bool useColliderToRaycast = false;

    public CollisionInfo collisions;
    [HideInInspector] public Vector2 playerInput;

    public override void Start() {
        base.Start();
    }

    public void Move(Vector2 moveAmount, bool standingOnPlatform = false) {
        Move (moveAmount, Vector2.zero, standingOnPlatform);
    } 

    public void Move(Vector2 moveAmount, Vector2 input, bool standingOnPlatform = false) {
        UpdateRaycastOrigins ();
        collisions.Reset ();
        collisions.moveAmountOld = moveAmount;
        playerInput = input;

        if (moveAmount.y < 0) {
            DescendSlope(ref moveAmount);
        }
        if (moveAmount.x != 0) {
            collisions.faceDir = (int)Mathf.Sign(moveAmount.x);
            // remove the (moveAmount.x != 0) if statement this to always check for horizontal collisions to do wall sliding at all times
            HorizontalCollisions (ref moveAmount);
        }
        if (moveAmount.y != 0) {
            VerticalCollisions (ref moveAmount);
        }


        transform.Translate (moveAmount);

        if (standingOnPlatform) {
            collisions.below = true;
        }
    }

    void HorizontalCollisions(ref Vector2 moveAmount) {
        float directionX = collisions.faceDir; //Mathf.Sign (moveAmount.x);
        float rayLength = Mathf.Abs(moveAmount.x) + skinWidth;

        // only nessesary if we remove the (moveAmount.x != 0) requirement for HorizontalCollisions
        if (Mathf.Abs(moveAmount.x) < skinWidth) {
            rayLength = 2 * skinWidth;
        }
        
        if (useColliderToRaycast) {
            Bounds skinnedBounds = colliderBox.bounds;
            skinnedBounds.Expand(skinWidth * -2);
            // version using collider.Raycast
            RaycastHit2D hit = Physics2D.BoxCast (raycastOrigins.bounds.center, skinnedBounds.size, 0, Vector2.right * directionX, rayLength, collisionMask);
            if (hit) HandleHorizontalHit(hit, ref moveAmount, ref rayLength, directionX);
        }
        else {
            // ray origin version
            for (int i = 0; i < horizontalRayCount; i++) {
                Vector2 rayOrigin = (directionX == -1)?raycastOrigins.bottomLeft:raycastOrigins.bottomRight;
                rayOrigin += Vector2.up * (horizontalRaySpacing * i);
                RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.right * directionX, rayLength, collisionMask);
                
                Debug.DrawRay(rayOrigin, Vector2.right * directionX * rayLength * 2, Color.red);

                if (hit) {
                    if (hit.collider.tag == "Cloud") {
                        continue;
                    }
                    if (hit.distance == 0) {
                        continue;
                    }
                    HandleHorizontalHit(hit, ref moveAmount, ref rayLength, directionX, i);
                }
            }
        }
    }

    void HandleHorizontalHit (RaycastHit2D hit, ref Vector2 moveAmount, ref float rayLength, float directionX, int i = 0) {
        float slopeAngle = Vector2.Angle (hit.normal, Vector2.up);

        // climbing slope
        if (i == 0 && slopeAngle <= maxSlopeAngle) {
            // fix for charachter slowing down in a V saped platform, where two steep slopes meet.
            if (collisions.descendingSlope) {
                collisions.descendingSlope = false;
                moveAmount = collisions.moveAmountOld;
            }
            float distToSlopeStart = 0;
            // move to slope, then climb
            if (slopeAngle != collisions.slopeAngleOld) {
                distToSlopeStart = hit.distance-skinWidth;
                moveAmount.x -= distToSlopeStart * directionX;
            }
            ClimbSlope(ref moveAmount, slopeAngle, hit.normal);
            // add back the distantance to slope so you close the distance to the slope
            moveAmount.x += distToSlopeStart * directionX;
        }

        if (!collisions.climbingSlope || slopeAngle > maxSlopeAngle) {
            moveAmount.x = (hit.distance - skinWidth) * directionX;
            rayLength = hit.distance;

            // update y moveAmount if climbing a slope so we dont jitter when we collide with something from the side
            if (collisions.climbingSlope) {
                moveAmount.y = Mathf.Tan(collisions.slopeAngle * Mathf.Deg2Rad) * Mathf.Abs(moveAmount.x);
            }

            collisions.left = directionX == -1;
            collisions.right = directionX == 1;
        }
    }

    void VerticalCollisions(ref Vector2 moveAmount) {
        float directionY = Mathf.Sign (moveAmount.y);
        float rayLength = Mathf.Abs(moveAmount.y) + skinWidth;

        // check for toe touching slope if moving down and has x velocity
        if (directionY == -1 && moveAmount.x != 0) ToeOnSlopeCheck(ref moveAmount);

        for (int i = 0; i < verticalRayCount; i++) {
            Vector2 rayOrigin = (directionY == -1)?raycastOrigins.bottomLeft:raycastOrigins.topLeft;
            rayOrigin += Vector2.right * (verticalRaySpacing * i + moveAmount.x);
            RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.up * directionY, rayLength, collisionMask);
            
            Debug.DrawRay(rayOrigin, Vector2.up * directionY * rayLength * 2, Color.red);

            if (hit) {
                if (hit.collider.tag == "Cloud") {
                    if (directionY == 1 || hit.distance == 0) {
                        continue;
                    }
                    if (collisions.fallingThroughPlatform) {
                        continue;
                    }
                    if (playerInput.y == -1) {
                        collisions.fallingThroughPlatform = true;
                        Invoke("ResetFallingThroughPlatform", 0.25f);
                        continue;
                    }
                }

                moveAmount.y = (hit.distance - skinWidth) * directionY;
                rayLength = hit.distance;

                // updates x moveAmount when on a slope and a collision above you occurs
                if (collisions.climbingSlope) {
                    moveAmount.x = moveAmount.y / Mathf.Tan(collisions.slopeAngle * Mathf.Deg2Rad) * Mathf.Sign(moveAmount.x);
                }

                collisions.below = directionY == -1;
                collisions.above = directionY == 1;
            }
        }
        
        // fix for charachter getting stuck for a frame when two slopes meet
        if (collisions.climbingSlope) {
            float directionX = Mathf.Sign(moveAmount.x);
            rayLength = Mathf.Abs(moveAmount.x) + skinWidth;
            Vector2 rayOrigin = ((directionX == -1)?raycastOrigins.bottomLeft:raycastOrigins.bottomRight) + Vector2.up * moveAmount.y;
            RaycastHit2D hit = Physics2D.Raycast(rayOrigin, Vector2.right * directionX, rayLength, collisionMask);
            
            if (hit) {
                float slopeAngle = Vector2.Angle(hit.normal, Vector2.up);
                if (slopeAngle != collisions.slopeAngle) {
                    moveAmount.x = (hit.distance - skinWidth) * directionX;
                    collisions.slopeAngle = slopeAngle;
                    collisions.slopeNormal = hit.normal;
                }
            }
        }
    }

    // if you edge up onto a slope without the horizontal collision detecting it, undo the x movement so you stay at the foot of the slope
    void ToeOnSlopeCheck(ref Vector2 moveAmount) {
            // fire a ray down from new ray origin (including x movement.)
            // if it hits inside skin width:
                // we use skinWidth - hit.distance to get the leg of the triangle + the angle of the normal to get the other leg (not the hypotonute).
                // We then subtract that distance from the moveAmount.x
            Vector2 rayOrigin = (moveAmount.x < 0)?raycastOrigins.bottomLeft:raycastOrigins.bottomRight;
            rayOrigin.x += moveAmount.x;
            RaycastHit2D hit = Physics2D.Raycast(rayOrigin, -Vector2.up, skinWidth * 1.1f, collisionMask);
            if (hit && hit.distance < skinWidth && hit.normal.y != 1) {
                float slopeAngle = Vector2.Angle(hit.normal, Vector2.up);
                float legLength = skinWidth - hit.distance;
                float xShift = legLength / Mathf.Tan(slopeAngle * Mathf.Deg2Rad);
                moveAmount += Vector2.right * xShift * Mathf.Sign(hit.normal.x);
            }
    }

    void ClimbSlope(ref Vector2 moveAmount, float slopeAngle, Vector2 slopeNormal) {
        float moveDistance = Mathf.Abs(moveAmount.x);
        float climbmoveAmountY = Mathf.Sin(slopeAngle * Mathf.Deg2Rad) * moveDistance;

        // if we are not jumping on a slope, climb the slope
        if (moveAmount.y <= climbmoveAmountY) {
            moveAmount.y = climbmoveAmountY;
            moveAmount.x = Mathf.Cos(slopeAngle * Mathf.Deg2Rad) * moveDistance * Mathf.Sign(moveAmount.x);
            collisions.below = true;
            collisions.climbingSlope = true;
            collisions.slopeAngle = slopeAngle;
            collisions.slopeNormal = slopeNormal;
        }
    }

    void DescendSlope(ref Vector2 moveAmount) {

        RaycastHit2D maxSlopeHitLeft =  Physics2D.Raycast(raycastOrigins.bottomLeft, -Vector2.up, Mathf.Abs(moveAmount.y) + skinWidth, collisionMask);
        RaycastHit2D maxSlopeHitRight = Physics2D.Raycast(raycastOrigins.bottomRight, -Vector2.up, Mathf.Abs(moveAmount.y) + skinWidth, collisionMask);
        
        //Debug.DrawRay(raycastOrigins.bottomLeft, -Vector2.up * (Mathf.Abs(moveAmount.y) + skinWidth), Color.black);
        if (maxSlopeHitLeft || maxSlopeHitRight) { //(maxSlopeHitLeft ^ maxSlopeHitRight)
            // fixes getting "captured" by a very gentle slope and being pulled down even when standing on flat ground
            if (maxSlopeHitLeft && maxSlopeHitRight) {
                // if the left hit is the closer one, only do left
                if (maxSlopeHitLeft.distance < maxSlopeHitRight.distance) SlideDownMaxSlope(maxSlopeHitLeft, ref moveAmount);
                // if the right hit is the closer one, only do right
                if (maxSlopeHitRight.distance < maxSlopeHitLeft.distance) SlideDownMaxSlope(maxSlopeHitRight, ref moveAmount);
            } 
            else {
                SlideDownMaxSlope(maxSlopeHitLeft, ref moveAmount);
                SlideDownMaxSlope(maxSlopeHitRight, ref moveAmount);
            }
        }


        if (!collisions.slidingDownMaxSlope) {
            float directionX = Mathf.Sign (moveAmount.x);
            Vector2 rayOrigin = (directionX == -1) ? raycastOrigins.bottomRight : raycastOrigins.bottomLeft;
            RaycastHit2D hit = Physics2D.Raycast(rayOrigin, -Vector2.up, Mathf.Infinity, collisionMask);

            if (hit) {
                float slopeAngle = Vector2.Angle(hit.normal, Vector2.up);
                if (slopeAngle != 0 && slopeAngle <= maxSlopeAngle) {
                    if (Mathf.Sign(hit.normal.x) == directionX) {
                        // if distance to slope is less than how far we have to move on the y access then we are close enough to use slope
                        if (hit.distance - skinWidth <= Mathf.Tan(slopeAngle * Mathf.Deg2Rad) * Mathf.Abs(moveAmount.x)) {
                            float moveDistance = Mathf.Abs(moveAmount.x);
                            float descendmoveAmountY = Mathf.Sin(slopeAngle * Mathf.Deg2Rad) * moveDistance;
                            moveAmount.x = Mathf.Cos(slopeAngle * Mathf.Deg2Rad) * moveDistance * Mathf.Sign(moveAmount.x);
                            moveAmount.y -= descendmoveAmountY;

                            collisions.slopeAngle = slopeAngle;
                            collisions.descendingSlope = true;
                            collisions.below = true;
                            collisions.slopeNormal = hit.normal;
                        }
                    }
                }
            }
        }
    }


    void SlideDownMaxSlope (RaycastHit2D hit, ref Vector2 moveAmount) {
        if (hit) {
            float slopeAngle = Vector2.Angle(hit.normal, Vector2.up);
            if (slopeAngle > maxSlopeAngle) {
                moveAmount.x = hit.normal.x * Mathf.Abs((Mathf.Abs(moveAmount.y) - hit.distance) / Mathf.Tan(slopeAngle * Mathf.Deg2Rad));
                collisions.slopeAngle = slopeAngle;
                collisions.slidingDownMaxSlope = true;
                collisions.slopeNormal = hit.normal;
            }
        }
    }

    void ResetFallingThroughPlatform() {
        collisions.fallingThroughPlatform = false;
    }

    public struct CollisionInfo {
        public bool above, below;
        public bool left, right;

        public bool climbingSlope;
        public bool descendingSlope;
        public bool slidingDownMaxSlope;

        public float slopeAngle, slopeAngleOld;
        public Vector2 slopeNormal;
        public Vector2 moveAmountOld;
        public int faceDir;
        public bool fallingThroughPlatform;

        public void Reset() {
            above = below = false;
            left = right = false;
            climbingSlope = false;
            descendingSlope = false;
            slidingDownMaxSlope = false;
            slopeNormal = Vector2.zero;

            slopeAngleOld = slopeAngle;
            slopeAngleOld = 0;
        }
    }
}
